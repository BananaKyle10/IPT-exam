Step 1: You kmust upload the database before you runnning this web application beacause it contains some data from the database
Step 2: The database name which is "ipt_project" then the table name which is "account"
Step 3: Need Xampp Application

Web application link: http://localhost/ipt_georgie/sample




---- HADOOP ----

• Sample usage of datanode and namenode
• Use case of how hadoop stored big data. 
• Anything that you may think beneficial to others in doing hadoop and bigdata.



Step 1: Before you install the hadoop you must install the JDK(JAVA).
Step 2: 