<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/admin.css') ?>">
</head>
<body>

<!-- header -->
	<header>
		<div class="head">
			<h3>data</h3>
		</div>
		<div class="list">
			<ul>
				<li><button>Delete</button></li>
				<li><button>Edit</button></li>
			</ul>
		</div>
	</header>
	<!-- end of header -->


	
	
</body>
</html>